﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_code_01
{
    class Player
    {
        public int money;


      /*  public Player(int money)
        {
            this.money = money;
        }*/
    }
}
